# игра

<!-- gdcapture:begin -->
<!-- gdcapture:item id=20260826213944111-428467800035100-8864 type=screenshot path=assets/6Nd5ukdoTf.png -->
![](<assets/6Nd5ukdoTf.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260826213958225-428481914221100-4597 type=screenshot path=assets/Stacklands_XWV5GL5vWN.png -->
![](<assets/Stacklands_XWV5GL5vWN.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:end -->
