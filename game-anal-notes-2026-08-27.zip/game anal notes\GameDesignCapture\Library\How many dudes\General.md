﻿# General

<!-- gdcapture:begin -->

<!-- gdcapture:item id=20260817015530-248815312-6912 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/ib4xa2D5Er.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/ib4xa2D5Er.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260817015530-248815312-2617 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/0O89PLDDQL.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/0O89PLDDQL.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260817015530-248815312-6912 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/ib4xa2D5Er.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/ib4xa2D5Er.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260817015530-248815312-2617 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/0O89PLDDQL.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/0O89PLDDQL.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260817015750-248955562-7388 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/explorer_bMejt3xXwn.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/explorer_bMejt3xXwn.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260817020104-249149484-1365 type=text -->
ваваав
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260818104539-367025906-4791 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/msedge_n001emmLDs.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/msedge_n001emmLDs.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260818112744-369550968-1994 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/msedge_k4GtVPTuIQ.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/msedge_k4GtVPTuIQ.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260818112754-369560968-4788 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/msedge_U8UMDnRbea.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/msedge_U8UMDnRbea.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260818112759-369566703-9886 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/msedge_nJghHQf1qz.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/msedge_nJghHQf1qz.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260818131525-376012578-9809 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/msedge_wmc8W0OZHA.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/msedge_wmc8W0OZHA.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260818131711-376118109-1454 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/msedge_7fDB8NXpKw.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/msedge_7fDB8NXpKw.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260818132446-376573843-1304 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/msedge_24982PANEL.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/msedge_24982PANEL.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260818132626-376673421-8252 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/msedge_7bpgxqSBXQ.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/msedge_7bpgxqSBXQ.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260818104446-366973625-8206 type=text -->
вв
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260817022457-250582093-7297 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/AutoHotkey64_JfYOAkl932.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/AutoHotkey64_JfYOAkl932.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260817023418-251143140-3975 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/AutoHotkey64_Z0cDwx9awh.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/AutoHotkey64_Z0cDwx9awh.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260817023755-251360890-4512 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/msedge_jUEwbsEIE9.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/msedge_jUEwbsEIE9.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260817024041-251526078-4372 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/msedge_iViJ6rsLxT.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/msedge_iViJ6rsLxT.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260817032411-254136546-3334 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/msedge_dzaWq3xST1.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/msedge_dzaWq3xST1.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260817041111-256956859-2198 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/explorer_FcS3NuKo8F.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/explorer_FcS3NuKo8F.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260817041846-257411062-2612 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/AutoHotkey64_vcHTmeINjF.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/AutoHotkey64_vcHTmeINjF.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260817044839-259204453-9531 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/msedge_rezcW0KJqH.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/msedge_rezcW0KJqH.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:item id=20260817015743-248948328-6367 type=screenshot path=GameDesignCapture/Games/How many dudes/assets/AutoHotkey64_PnPzmYVm02.png -->
![](<assets/GameDesignCapture/Games/How many dudes/assets/AutoHotkey64_PnPzmYVm02.png>)
<!-- /gdcapture:item -->

<!-- gdcapture:end --><!-- gdcapture:screenshot=GameDesignCapture/Games/How many dudes/assets/explorer_KUkyBquTRn.png -->
![[GameDesignCapture/Games/How many dudes/assets/explorer_KUkyBquTRn.png]]

<!-- gdcapture:screenshot=GameDesignCapture/Games/How many dudes/assets/kAWmLl5gcP.png -->
![[GameDesignCapture/Games/How many dudes/assets/kAWmLl5gcP.png]]

